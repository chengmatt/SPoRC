library(SPoRC)
library(r4ss)
source("R/ss3_to_sporc_data.R")

RUN_DIR <- "ss3"

## SPoRC arrays -----------------------------------------------------------------
dat <- ss3_to_sporc_data(RUN_DIR)

yrs <- dat$years
ages <- dat$ages
acols <- as.character(ages)

## SS3's answers ----------------------------------------------------------------

# Report.sso prints six significant digits; ss.par carries twelve, so parameters
# come from the par file and derived series from the report.
rep_ss3 <- SS_output(RUN_DIR, verbose = FALSE, printstats = FALSE, covar = FALSE,
                     forecast = FALSE, warn = FALSE)
paths <- ss3_paths(RUN_DIR)
par_ss3 <- SS_readpar_3.30(file.path(RUN_DIR, "ss.par"), datsource = paths$dat,
                           ctlsource = paths$ctl, verbose = FALSE)

# numbers at age at the start of the year
na <- rep_ss3$natage[rep_ss3$natage$`Beg/Mid` == "B" & rep_ss3$natage$Era == "TIME", ]
NAA_ss3 <- as.matrix(na[match(yrs, na$Yr), acols])

ts <- rep_ss3$timeseries[rep_ss3$timeseries$Era == "TIME", ]
ti <- match(yrs, ts$Yr)

# fishing mortality at age; selectivity is normalized to one, so the apical rate
# is the maximum over ages
fa <- rep_ss3$ageselex[rep_ss3$ageselex$Factor == "F" & rep_ss3$ageselex$Fleet == 1, ]
FAA_ss3 <- as.matrix(fa[match(yrs, fa$Yr), acols])

# selectivity at age, which does not vary by year in this assessment
asel <- rep_ss3$ageselex[rep_ss3$ageselex$Factor == "Asel" & rep_ss3$ageselex$Yr == max(yrs), ]

# recruitment deviations at twelve digits: early, main, then the terminal "late"
# deviation, which SS3 files under forecast
all_dev <- rbind(par_ss3$recdev_early, par_ss3$recdev1, par_ss3$recdev_forecast)
recdev <- rep(0, length(yrs))
hit <- match(all_dev[, 1], yrs)
recdev[hit[!is.na(hit)]] <- all_dev[!is.na(hit), 2]

# the bias ramp SS3 applied, on the model years
biasadj <- rep_ss3$recruit$biasadjuster[match(yrs, rep_ss3$recruit$Yr)]
biasadj[is.na(biasadj)] <- 0

dat$ss3 <- list(
  NAA = NAA_ss3, FAA = FAA_ss3, F_apical = apply(FAA_ss3, 1, max),
  SSB = ts$SpawnBio[ti], Bio_all = ts$Bio_all[ti], Rec = ts$Recruit_0[ti],
  dead_B = ts[[grep("^dead\\(B\\)", names(ts))[1]]][ti],
  sel_fish = as.numeric(asel[asel$Fleet == 1, acols]),
  sel_srv = as.numeric(asel[asel$Fleet == 2, acols]),
  recdev = recdev, biasadj = biasadj,
  cpue = rep_ss3$cpue, likelihoods = rep_ss3$likelihoods_used,
  ln_R0 = par_ss3$SR_parms["SR_LN(R0)", "ESTIM"],
  h = par_ss3$SR_parms["SR_BH_steep", "ESTIM"],
  sigmaR = par_ss3$SR_parms["SR_sigmaR", "ESTIM"],
  init_F = as.numeric(par_ss3$init_F)[1],
  ln_q = par_ss3$Q_parms["LnQ_base_Acoustics(2)", "ESTIM"],
  sel_pars = par_ss3$S_parms,
  report = rep_ss3
)

dir.create("output", showWarnings = FALSE)
saveRDS(dat, "output/01_ss3.rds")
