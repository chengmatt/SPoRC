# 02  Build the SPoRC model
#
# Run with dev/cbh_bridge as the working directory.
# Reads output/01_ss3.rds, writes output/02_input_list.rds.
#
# This is the specification: which parameters are estimated, and how each SS3
# setting is written in SPoRC. The data are already in shape by this point.
#
# HerringSD2532 is 1903-2024, one season, one sex, one area, ages 0-8 with 8 the
# accumulator, one fishery and one acoustic survey.

library(SPoRC)

dat <- readRDS("output/01_ss3.rds")

yrs <- dat$years
ages <- dat$ages
n_yrs <- length(yrs)
n_ages <- length(ages)
n_reg <- dat$n_regions
n_sex <- dat$n_sexes
n_fish <- dat$n_fish_fleets
n_srv <- dat$n_srv_fleets

# comp type strings; with one region and one sex the split is the identity
splt <- paste0("spltRspltS_Year_1-terminal_Fleet_", 1)
none <- paste0("none_Year_1-terminal_Fleet_", 1)

## Selectivity, translated from SS3 pattern 17 ----------------------------------

# SS3 Selectivity Increments for random walk
sel <- list()

for(fleet in c("Fleet", "Acoustics")) {

  rows <- grep(paste0("_", fleet, "[(]"), rownames(dat$sel$age))
  init <- dat$ss3$sel_pars[grep(paste0("_", fleet, "[(]"), rownames(dat$ss3$sel_pars)), "ESTIM"]
  est_inc <- dat$sel$age[rows, "PHASE"] > 0

  zero <- init <= -999
  logsel <- rep(-Inf, n_ages)
  logsel[!zero] <- cumsum(init[!zero])
  logsel <- logsel - max(logsel[!zero])

  # the derivation above holds while the curve is non-decreasing
  if(any(diff(logsel[!zero]) < 0)) stop("pattern 17 curve for ", fleet, " is not monotone")

  est <- rep(FALSE, n_ages)
  est[which(est_inc) - 1] <- TRUE
  est[zero] <- FALSE

  # under "nonparfree" selectivity is exp(par), so an age SS3 sets to exactly
  # zero needs a value far enough down to be zero at working precision: -30 is
  # 9.4e-14, where -10 is 4.5e-5 and shows up in every comparison
  start <- logsel
  start[zero] <- -30

  sel[[fleet]] <- list(start = start, est = est)

} # end fleet loop

## Model dimensions -------------------------------------------------------------
# one population in one area with an annual time step, so every region, season
# and sex subscript below is length one
input_list <- Setup_Mod_Dim(
  years = yrs, ages = ages, lens = dat$lens,
  n_regions = n_reg, n_sexes = n_sex, n_fish_fleets = n_fish, n_srv_fleets = n_srv,
  n_seas = 1, n_pop = 1, natal_region = 1, verbose = FALSE
)

## Recruitment ------------------------------------------------------------------
# Beverton-Holt with R0 and steepness estimated, sigmaR fixed at the control
# file's 0.5, and the bias ramp from SS3's four ramp years, given in
# deviation-index space where 1 is the first model year.

# think 1903 is a deterministic equilibrium under a fixed initial F. SS3 estimates no
# Early_InitAge parameters here, so there are no initial-age deviations either.
input_list <- Setup_Mod_Rec(
  input_list = input_list,
  rec_model = "bh_rec", rec_dd = "global", rec_lag = 0, SR_ref_yr = 1,
  t_spawn = (dat$spawn_month - 1) / 12,
  sigmaR_spec = "fix",
  ln_sigmaR = array(log(dat$ss3$sigmaR), dim = c(2, 1, n_reg)), sigmaR_switch = 1,
  do_rec_bias_ramp = 1,
  bias_year = dat$rec$bias_years - yrs[1] + 1,
  max_bias_ramp_fct = dat$rec$max_bias_adj,
  RecDevs_spec = "est_shared_pop_r",
  RecDevs_pen_center = "fixed",
  dont_est_recdev_last = 0,
  init_age_strc = 'matrix',
  equil_init_age_strc = 'equil',
  init_F_form = "abs", init_F_spec = "fix",
  init_F_par = array(log(dat$ss3$init_F), dim = c(n_reg, 1, n_fish)),
  h_spec = "est_shared_r",
  ln_global_R0 = dat$ss3$ln_R0
)

## Biological dynamics ----------------------------------------------------------
# natural mortality is fixed and varies by age and year
input_list <- Setup_Mod_Biologicals(
  input_list = input_list,
  WAA = dat$WAA, MatAA = dat$MatAA,
  M_spec = "fix", Fixed_natmort = dat$Fixed_natmort,
  AgeingError = dat$AgeingError,
  fit_lengths = 0, SizeAgeTrans = NA,
  growth_model = "none",
  addtocomp = dat$comp$age_info$addtocomp[1], comp_const_obs = 1,
  addtofishidx = 0, addtosrvidx = 0
)

## Movement and tagging ---------------------------------------------------------
# one area, so nothing moves and nothing is tagged
input_list <- Setup_Mod_Movement(input_list = input_list, use_fixed_movement = 1,
                                 Fixed_Movement = NA, do_recruits_move = 0)
input_list <- Setup_Mod_Tagging(input_list = input_list, use_conv_fish_tagging = 0)

## Catch and fishing mortality --------------------------------------------------
# SS3 solves F from the catch with its hybrid method and spends no parameters on
# it. SPoRC estimates a deviation per year against the catch standard error the
# data file gives, 0.1 through 2022 and 0.05 after, with no penalty, which is
# what the hybrid method implies.
input_list <- Setup_Mod_Catch_and_F(
  input_list = input_list,
  ObsCatch = dat$ObsCatch,
  UseCatch = dat$UseCatch,
  Use_F_pen = 0,
  ln_F_mean_spec = "fix",
  sigmaC_spec = "fix",
  ln_sigmaC = array(log(dat$catch_se), dim = c(n_reg, n_yrs, 1, n_fish))
)

## Fishery compositions ---------------------------------------------------------
# no fishery index. Catch at age is Dirichlet-multinomial
input_list <- Setup_Mod_FishIdx_and_Comps(
  input_list = input_list,
  t_fish = array(0.5, dim = c(n_reg, 1, n_fish)),
  ObsFishIdx = array(NA_real_, dim = c(n_reg, n_yrs, 1, n_fish)),
  ObsFishIdx_SE = array(NA_real_, dim = c(n_reg, n_yrs, 1, n_fish)),
  UseFishIdx = array(0, dim = c(n_reg, n_yrs, 1, n_fish)),
  fish_idx_type = "none",
  FishIdx_LikeType = "lognormal",

  # fishery ages
  ObsFishAgeComps = dat$ObsFishAgeComps,
  UseFishAgeComps = dat$UseFishAgeComps,
  ISS_FishAgeComps = dat$ISS_FishAgeComps,
  FishAgeComps_LikeType = "Dirichlet-Multinomial",
  FishAgeComps_Type = splt,
  FishAgeComps_bins = list(dat$obs_ages),
  ObsFishLenComps = array(NA_real_, dim = c(n_reg, n_yrs, 1, length(dat$lens), n_sex, n_fish)),
  UseFishLenComps = array(0, dim = c(n_reg, n_yrs, 1, n_fish)),
  ISS_FishLenComps = array(0, dim = c(n_reg, n_yrs, 1, n_sex, n_fish)),
  FishLenComps_LikeType = "none", FishLenComps_Type = none
)

## Survey index and compositions ------------------------------------------------
# the acoustic index is in numbers, fit lognormally, taken in month 10
input_list <- Setup_Mod_SrvIdx_and_Comps(
  input_list = input_list,
  ObsSrvIdx = dat$ObsSrvIdx, ObsSrvIdx_SE = dat$ObsSrvIdx_SE, UseSrvIdx = dat$UseSrvIdx,
  srv_idx_type = ifelse(dat$srv_idx_type == 1, "biom", "abd"),
  SrvIdx_LikeType = "lognormal",
  ObsSrvAgeComps = dat$ObsSrvAgeComps, UseSrvAgeComps = dat$UseSrvAgeComps,
  ISS_SrvAgeComps = dat$ISS_SrvAgeComps,
  SrvAgeComps_LikeType = "Dirichlet-Multinomial", SrvAgeComps_Type = splt,
  SrvAgeComps_bins = list(dat$obs_ages),
  ObsSrvLenComps = array(NA_real_, dim = c(n_reg, n_yrs, 1, length(dat$lens), n_sex, n_srv)),
  UseSrvLenComps = array(0, dim = c(n_reg, n_yrs, 1, n_srv)),
  ISS_SrvLenComps = array(0, dim = c(n_reg, n_yrs, 1, n_sex, n_srv)),
  SrvLenComps_LikeType = "none", SrvLenComps_Type = none,
  t_srv = array(dat$t_srv, dim = c(n_reg, 1, n_srv))
)

## Selectivity and catchability -------------------------------------------------
# est_bins lists the age positions that carry a parameter; an age left out is
# held at its starting value
input_list <- Setup_Mod_Fishsel_and_Q(
  input_list = input_list,
  fish_sel_model = "nonparfree_Fleet_1",
  cont_tv_fish_sel = "none_Fleet_1",
  fish_sel_blocks = "none_Fleet_1",
  fish_q_blocks = "none_Fleet_1",
  fish_sel_nonpar_est_bins = list(list(as.list(which(sel$Fleet$est)))), # bins to estimate ...  \code{[[fleet]][[block]]}
  fish_fixed_sel_pars_spec = "est_all",
  fish_q_spec = "fix"
)

input_list <- Setup_Mod_Srvsel_and_Q(
  input_list = input_list,
  srv_sel_model = "nonparfree_Fleet_1",
  cont_tv_srv_sel = "none_Fleet_1",
  srv_sel_blocks = "none_Fleet_1",
  srv_q_blocks = "none_Fleet_1",
  srv_sel_nonpar_est_bins = list(list(as.list(which(sel$Acoustics$est)))), # bins to estimate ...  \code{[[fleet]][[block]]}
  srv_fixed_sel_pars_spec = "est_all",
  srv_q_spec = "est_all",
  t_srv = array(dat$t_srv, dim = c(n_reg, 1, n_srv))
)

# fish_fixed_sel_pars is [region, age, block, sex, fleet]
input_list$par$fish_fixed_sel_pars[1, , 1, 1, 1] <- sel$Fleet$start
input_list$par$srv_fixed_sel_pars[1, , 1, 1, 1] <- sel$Acoustics$start

## Weighting --------------------------------------------------------------------
# the Dirichlet-multinomial estimates its own weight, so every composition
# enters at one
wt_one <- array(1, dim = c(n_reg, n_yrs, 1, n_sex, 1))

input_list <- Setup_Mod_Weighting(
  input_list = input_list,
  Wt_Catch = 1, Wt_FishIdx = 0, Wt_SrvIdx = 1, Wt_Rec = 1, Wt_F = 1, Wt_Tagging = 0,
  Wt_FishAgeComps = wt_one, Wt_SrvAgeComps = wt_one,
  Wt_FishLenComps = wt_one, Wt_SrvLenComps = wt_one
)

saveRDS(list(input_list = input_list, sel = sel), "output/02_input_list.rds")
