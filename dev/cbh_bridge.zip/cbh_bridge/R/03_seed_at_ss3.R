# 03  Evaluate SPoRC at SS3's estimate
#
# Run with dev/cbh_bridge as the working directory.
# Reads output/01_ss3.rds and output/02_input_list.rds.
#
# This is the bridge. Every parameter is set to SS3's own maximum likelihood
# estimate and the reported quantities are compared before the optimizer is
# allowed to move anything. If the population dynamics are written the same way,
# they agree here to SS3's print precision.

library(SPoRC)

dat <- readRDS("output/01_ss3.rds")
built <- readRDS("output/02_input_list.rds")
input_list <- built$input_list
sel <- built$sel
s <- dat$ss3
yrs <- dat$years
n_yrs <- length(yrs)

fix_all <- function(x) factor(rep(NA, length(x)))

## Recruitment ------------------------------------------------------------------
input_list$par$ln_global_R0[] <- s$ln_R0
input_list$par$steepness_h[] <- qlogis((s$h - 0.2) / 0.8)
input_list$map$ln_global_R0 <- fix_all(input_list$par$ln_global_R0)
input_list$map$steepness_h <- fix_all(input_list$par$steepness_h)
input_list$par$ln_RecDevs[1, 1, ] <- s$recdev - 0.5 * s$sigmaR^2 * s$biasadj

# deviations run 1966 to 2024; the years SS3 leaves at the stock recruit
# prediction carry no parameter
rd_map <- rep(NA_integer_, n_yrs)
est <- which(s$recdev != 0)
rd_map[est] <- seq_along(est)
input_list$map$ln_RecDevs <- factor(rd_map)

## Fishing mortality ------------------------------------------------------------
# SS3 solves F from the catch rather than estimating it, so the apical rate is
# read off the report and kept fixed here
input_list$par$ln_F_mean[] <- 0
input_list$par$ln_F_devs[1, , 1, 1] <- log(s$F_apical)
input_list$map$ln_F_mean <- fix_all(input_list$par$ln_F_mean)
input_list$map$ln_F_devs <- fix_all(input_list$par$ln_F_devs)

## Catchability, selectivity, overdispersion ------------------------------------
input_list$par$ln_srv_q[] <- s$ln_q
input_list$par$fish_fixed_sel_pars[1, , 1, 1, 1] <- sel$Fleet$start
input_list$par$srv_fixed_sel_pars[1, , 1, 1, 1] <- sel$Acoustics$start
input_list$par$ln_FishAge_theta[] <- s$sel_pars["ln(DM_theta)_1", "ESTIM"]
input_list$par$ln_SrvAge_theta[] <- s$sel_pars["ln(DM_theta)_2", "ESTIM"]

for(k in c("ln_srv_q", "fish_fixed_sel_pars", "srv_fixed_sel_pars",
           "ln_FishAge_theta", "ln_SrvAge_theta")) {
  input_list$map[[k]] <- fix_all(input_list$par[[k]])
} # end k loop

## Evaluate ---------------------------------------------------------------------

obj <- fit_model(input_list$data, input_list$par, input_list$map,
                 random = NULL, newton_loops = 0, do_optim = FALSE, silent = TRUE)
rep <- obj$report(obj$env$last.par)

pct <- function(a, b) 100 * max(abs(a - b) / pmax(abs(b), 1e-12), na.rm = TRUE)
NAA <- t(sapply(seq_along(yrs), function(i) as.numeric(rep$NAA[1, 1, i, 1, , 1])))
WAA <- t(sapply(seq_along(yrs), function(i) dat$WAA[1, 1, i, 1, , 1]))
cp <- s$cpue[s$cpue$Use == 1, ]

comparison <- data.frame(
  quantity = c("numbers at age", "spawning biomass (x2)", "recruitment", "total biomass",
               "catch", "survey index", "fishery selectivity", "survey selectivity"),
  pct_diff = c(
    pct(NAA, s$NAA),
    pct(2 * as.numeric(rep$SSB), s$SSB),
    pct(as.numeric(rep$Rec), s$Rec),
    pct(apply(NAA * WAA, 1, sum), s$Bio_all),
    pct(as.numeric(rep$PredCatch), s$dead_B),
    pct(as.numeric(rep$PredSrvIdx)[match(cp$Yr, yrs)], cp$Exp),
    pct(as.numeric(rep$fish_sel[1, 1, 1, 1, , 1, 1])[-1], s$sel_fish[-1]),
    pct(as.numeric(rep$srv_sel[1, 1, 1, 1, , 1, 1])[-1], s$sel_srv[-1])
  ),
  row.names = NULL
)

## Likelihood -------------------------------------------------------------------

g <- function(k) sum(as.numeric(rep[[k]]), na.rm = TRUE)
n_idx <- nrow(cp)
n_dev <- sum(s$recdev != 0)

# look at likelihood differences
likelihood <- data.frame(
  component = c("survey index", "age compositions", "recruitment", "catch"),
  SPoRC = c(g("SrvIdx_nLL"), g("FishAgeComps_nLL") + g("SrvAgeComps_nLL"),
            g("Rec_nLL"), g("Catch_nLL")),
  SS3 = c(s$likelihoods["Survey", "values"], s$likelihoods["Age_comp", "values"],
          s$likelihoods["Recruitment", "values"], s$likelihoods["Catch", "values"]),
  residual = c(
    g("SrvIdx_nLL") - s$likelihoods["Survey", "values"] - n_idx * 0.5 * log(2 * pi),
    NA,
    g("Rec_nLL") - (sum(s$recdev^2) / (2 * s$sigmaR^2) +
                    0.5 * sum(s$biasadj) * log(s$sigmaR) + n_dev * 0.5 * log(2 * pi)),
    g("Catch_nLL") - (sum(log(as.numeric(dat$catch_se))) + n_yrs * 0.5 * log(2 * pi))
  ),
  row.names = NULL
)

saveRDS(list(input_list = input_list, rep = rep, comparison = comparison,
             likelihood = likelihood, objective = obj$fn(obj$env$last.par)),
        "output/03_seeded.rds")
