library(SPoRC)

dat <- readRDS("output/01_ss3.rds")
seeded <- readRDS("output/03_seeded.rds")
input_list <- seeded$input_list
s <- dat$ss3
yrs <- dat$years

## Release what SS3 estimated ---------------------------------------------------
# The composition overdispersion fixed at SS3's estimate. F is freely estimated

free <- readRDS("output/02_input_list.rds")$input_list

release <- c("ln_global_R0", "steepness_h", "ln_srv_q",
             "fish_fixed_sel_pars", "srv_fixed_sel_pars", "ln_F_devs")
for(k in release) input_list$map[[k]] <- free$map[[k]]

fit <- fit_model(input_list$data, input_list$par, input_list$map,
                 random = NULL, newton_loops = 5, silent = TRUE)

par <- fit$env$last.par.best
rep <- fit$report(par)
sd <- RTMB::sdreport(fit, hessian.fixed = fit$he())
post_optim_sanity_checks(sd, rep)

pct <- function(a, b) 100 * max(abs(a - b) / pmax(abs(b), 1e-12), na.rm = TRUE)
NAA <- t(sapply(seq_along(yrs), function(i) as.numeric(rep$NAA[1, 1, i, 1, , 1])))

estimates <- data.frame(
  parameter = c("ln R0", "steepness", "ln q"),
  SPoRC = c(par[names(par) == "ln_global_R0"],
            0.2 + 0.8 * plogis(par[names(par) == "steepness_h"]),
            par[names(par) == "ln_srv_q"]),
  SS3 = c(s$ln_R0, s$h, s$ln_q),
  row.names = NULL
)

fit_summary <- list(
  objective = fit$fn(par),
  objective_at_ss3 = seeded$objective,
  ssb_pct_from_ss3 = pct(2 * as.numeric(rep$SSB), s$SSB),
  naa_pct_from_ss3 = pct(NAA, s$NAA),
  pdHess = sd$pdHess,
  min_eigenvalue = min(eigen(fit$he(par), symmetric = TRUE, only.values = TRUE)$values)
)

## Standard errors --------------------------------------------------------------

# get standard errors
std <- read.table("ss3/ss.std", header = TRUE,
                  col.names = c("index", "name", "value", "std.dev"), fill = TRUE)
C <- sd$cov.fixed
nm <- names(par)

dev_pos <- which(nm == "ln_RecDevs")
dev_yrs <- yrs[s$recdev != 0]
main_pos <- dev_pos[dev_yrs >= 1974 & dev_yrs <= 2023]
early_pos <- dev_pos[dev_yrs < 1974]

A <- matrix(0, 1, nrow(C))
A[1, main_pos] <- 1
CA <- C %*% t(A)
C_sum0 <- C - CA %*% solve(A %*% CA) %*% t(CA)

se <- function(cov, i) sqrt(diag(cov))[i]
ss3_sr <- std$std.dev[grepl("^SR_parm", std$name)]

standard_errors <- data.frame(
  parameter = c("ln R0", "steepness", "main deviations (median)", "early deviations (median)"),
  free = c(se(C, nm == "ln_global_R0"), se(C, nm == "steepness_h"),
           median(se(C, main_pos)), median(se(C, early_pos))),
  sum_to_zero = c(se(C_sum0, nm == "ln_global_R0"), se(C_sum0, nm == "steepness_h"),
                  median(se(C_sum0, main_pos)), median(se(C_sum0, early_pos))),
  SS3 = c(ss3_sr[1], ss3_sr[2],
          median(std$std.dev[std$name == "recdev1"]),
          median(std$std.dev[std$name == "recdev_early"])),
  row.names = NULL
)

saveRDS(list(par = par, rep = rep, sd = sd, cov_sum0 = C_sum0,
             estimates = estimates, fit_summary = fit_summary,
             standard_errors = standard_errors),
        "output/04_refit.rds")
