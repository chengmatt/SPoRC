# Central Baltic herring: SS3 to SPoRC

```r
source("R/01_read_ss3.R")     # SS3 files in, SPoRC arrays and SS3's answers out
source("R/02_build_model.R")  # model specification
source("R/03_seed_at_ss3.R")  # evaluate at SS3's estimate: this is the bridge
source("R/04_refit.R")        # SPoRC's own optimum, and standard errors
```

Each reads the one before it through `output/`. 

```r
readRDS("output/03_seeded.rds")$comparison       # the bridge
readRDS("output/03_seeded.rds")$likelihood       # with residuals per convention
readRDS("output/04_refit.rds")$estimates
readRDS("output/04_refit.rds")$standard_errors
```

At SS3's estimate every population quantity agrees to 0.00045 percent, which
is SS3's print precision. Likelihoods differ only by constants SS3 omits.

`R/ss3_to_sporc_data.R` is generic to any SS3 run folder. `ss3/` holds only the
files the scripts read. The conventions that are easy to get wrong are commented
where they are handled, in `02` and `03`.
