#V3.30.20.00;_safe;_compile_date:_Sep 30 2022;_Stock_Synthesis_by_Richard_Methot_(NOAA)_using_ADMB_13.0
#_Stock_Synthesis_is_a_work_of_the_U.S._Government_and_is_not_subject_to_copyright_protection_in_the_United_States.
#_Foreign_copyrights_may_apply._See_copyright.txt_for_more_information.
#_User_support_available_at:NMFS.Stock.Synthesis@noaa.gov
#_User_info_available_at:https://vlab.noaa.gov/group/stock-synthesis
#_Source_code_at:_https://github.com/nmfs-stock-synthesis/stock-synthesis

#C control file for Herring SD 30-31 (1 fleet 2 surveys)
#_data_and_control_files: HerringSD2532.dat // HerringSD2532.ctl
1  # 0 means do not read wtatage.ss; 1 means read and use wtatage.ss and also read and use growth parameters
1  #_N_Growth_Patterns (Growth Patterns, Morphs, Bio Patterns, GP are terms used interchangeably in SS3)
1 #_N_platoons_Within_GrowthPattern 
#_Cond 1 #_Platoon_within/between_stdev_ratio (no read if N_platoons=1)
#_Cond  1 #vector_platoon_dist_(-1_in_first_val_gives_normal_approx)
#
4 # recr_dist_method for parameters:  2=main effects for GP, Area, Settle timing; 3=each Settle entity; 4=none (only when N_GP*Nsettle*pop==1)
1 # not yet implemented; Future usage: Spawner-Recruitment: 1=global; 2=by area
1 #  number of recruitment settlement assignments 
0 # unused option
#GPattern month  area  age (for each settlement assignment)
 1 1 1 0
#
#_Cond 0 # N_movement_definitions goes here if Nareas > 1
#_Cond 1.0 # first age that moves (real age at begin of season, not integer) also cond on do_migration>0
#_Cond 1 1 1 2 4 10 # example move definition for seas=1, morph=1, source=1 dest=2, age1=4, age2=10
#
1 #_Nblock_Patterns
 51 #_blocks_per_pattern 
# begin and end years of blocks
 1903	1974	1975	1975	1976	1976	1977	1977	1978	1978	1979	1979	1980	1980	1981	1981	1982	1982	1983	1983	1984	1984	1985	1985	1986	1986	1987	1987	1988	1988	1989	1989	1990	1990	1991	1991	1992	1992	1993	1993	1994	1994	1995	1995	1996	1996	1997	1997	1998	1998	1999	1999	2000	2000	2001	2001	2002	2002	2003	2003	2004	2004	2005	2005	2006	2006	2007	2007	2008	2008	2009	2009	2010	2010	2011	2011	2012	2012	2013	2013	2014	2014	2015	2015	2016	2016	2017	2017	2018	2018	2019	2019	2020	2020	2021	2021  2022  2022 2023 2023 2024 2027 
#
# controls for all timevary parameters 
1 #_time-vary parm bound check (1=warn relative to base parm bounds; 3=no bound check); Also see env (3) and dev (5) options to constrain with base bounds
#
# AUTOGEN
 1 1 1 1 1 # autogen: 1st element for biology, 2nd for SR, 3rd for Q, 4th reserved, 5th for selex
# where: 0 = autogen time-varying parms of this category; 1 = read each time-varying parm line; 2 = read then autogen if parm min==-12345
#
#_Available timevary codes
#_Block types: 0: P_block=P_base*exp(TVP); 1: P_block=P_base+TVP; 2: P_block=TVP; 3: P_block=P_block(-1) + TVP
#_Block_trends: -1: trend bounded by base parm min-max and parms in transformed units (beware); -2: endtrend and infl_year direct values; -3: end and infl as fraction of base range
#_EnvLinks:  1: P(y)=P_base*exp(TVP*env(y));  2: P(y)=P_base+TVP*env(y);  3: P(y)=f(TVP,env_Zscore) w/ logit to stay in min-max;  4: P(y)=2.0/(1.0+exp(-TVP1*env(y) - TVP2))
#_DevLinks:  1: P(y)*=exp(dev(y)*dev_se;  2: P(y)+=dev(y)*dev_se;  3: random walk;  4: zero-reverting random walk with rho;  5: like 4 with logit transform to stay in base min-max
#_DevLinks(more):  21-25 keep last dev for rest of years
#
#_Prior_codes:  0=none; 6=normal; 1=symmetric beta; 2=CASAL's beta; 3=lognormal; 4=lognormal with biascorr; 5=gamma
#
# setup for M, growth, wt-len, maturity, fecundity, (hermaphro), recr_distr, cohort_grow, (movement), (age error), (catch_mult), sex ratio 
#_NATMORT
1 #_natM_type:_0=1Parm; 1=N_breakpoints;_2=Lorenzen;_3=agespecific;_4=agespec_withseasinterpolate;_5=BETA:_Maunder_link_to_maturity;_6=Lorenzen_range
9 #_N_breakpoints
 0.5 1 2 3 4 5 6 7 8 # age(real) at M breakpoints
#
1 # GrowthModel: 1=vonBert with L1&L2; 2=Richards with L1&L2; 3=age_specific_K_incr; 4=age_specific_K_decr; 5=age_specific_K_each; 6=NA; 7=NA; 8=growth cessation
0.1 #_Age(post-settlement)_for_L1;linear growth below this
999 #_Growth_Age_for_L2 (999 to use as Linf)
-999 #_exponential decay for growth above maxage (value should approx initial Z; -999 replicates 3.24; -998 to not allow growth above maxage)
0  #_placeholder for future growth feature
#
0 #_SD_add_to_LAA (set to 0.1 for SS2 V1.x compatibility)
0 #_CV_Growth_Pattern:  0 CV=f(LAA); 1 CV=F(A); 2 SD=F(LAA); 3 SD=F(A); 4 logSD=F(A)
#
2 #_maturity_option:  1=length logistic; 2=age logistic; 3=read age-maturity matrix by growth_pattern; 4=read age-fecundity; 5=disabled; 6=read length-maturity
1 #_First_Mature_Age
1 #_fecundity_at_length option:(1)eggs=Wt*(a+b*Wt);(2)eggs=a*L^b;(3)eggs=a*Wt^b; (4)eggs=a+b*L; (5)eggs=a+b*W
0 #_hermaphroditism option:  0=none; 1=female-to-male age-specific fxn; -1=male-to-female age-specific fxn
1 #_parameter_offset_approach for M, G, CV_G:  1- direct, no offset**; 2- male=fem_parm*exp(male_parm); 3: male=female*exp(parm) then old=young*exp(parm)
#_** in option 1, any male parameter with value = 0.0 and phase <0 is set equal to female parameter
#
#_growth_parms
#_ LO HI INIT PRIOR PR_SD PR_type PHASE env_var&link dev_link dev_minyr dev_maxyr dev_PH Block Block_Fxn
# Sex: 1  BioPattern: 1  NatMort M1_010
 0.1 2.4 0.466 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_0_Fem_GP_1
 0.1 2.4 0.436 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_1_Fem_GP_1
 0.1 2.4 0.299 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_2_Fem_GP_1
 0.1 2.4 0.237 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_3_Fem_GP_1
 0.1 2.4 0.216 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_4_Fem_GP_1
 0.1 2.4 0.202 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_5_Fem_GP_1
 0.1 2.4 0.200 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_6_Fem_GP_1
 0.1 2.4 0.185 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_7_Fem_GP_1
 0.1 2.4 0.155 0.15 0.8 0 -1 0 0 0 0 0 1 2 # NatM_break_8+_Fem_GP_1

# Sex: 1  BioPattern: 1  Growth
 0 20 4 4 10 0 -2 0 0 0 0 0 0 0 # L_at_Amin_Fem_GP_1
 10 50 35 20 10 0 -4 0 0 0 0 0 0 0 # L_at_Amax_Fem_GP_1
 0.05 0.8 0.2 0.47 0.8 0 -4 0 0 0 0 0 0 0 # VonBert_K_Fem_GP_1
 0.05 0.5 0.2 0.5 0.8 0 -3 0 0 0 0 0 0 0 # CV_young_Fem_GP_1
 0.1 0.7 0.2 0.5 0.8 0 -3 0 0 0 0 0 0 0 # CV_old_Fem_GP_1
# Sex: 1  BioPattern: 1  WtLen
 -3 3 4e-06 4e-06 0.8 0 -99 0 0 0 0 0 0 0 # Wtlen_1_Fem_GP_1
 -3 4 3.05 3.0962 0.8 0 -99 0 0 0 0 0 0 0 # Wtlen_2_Fem_GP_1
# Sex: 1  BioPattern: 1  Maturity&Fecundity
 0 6 0.13 2 0.8 0 -99 0 0 0 0 0 0 0 # Mat50%_Fem_GP_1
 -5 3 -4.149 -0.25 0.8 0 -99 0 0 0 0 0 0 0 # Mat_slope_Fem_GP_1
 -3 3 1 1 0.8 0 -99 0 0 0 0 0 0 0 # Eggs/kg_inter_Fem_GP_1
 -3 3 0 0 0.8 0 -99 0 0 0 0 0 0 0 # Eggs/kg_slope_wt_Fem_GP_1
# Hermaphroditism
#  Recruitment Distribution 
#  Cohort growth dev base
 0.1 10 1 1 1 0 -1 0 0 0 0 0 0 0 # CohortGrowDev
#  Movement
#  Age Error from parameters
#  catch multiplier
#  fraction female, by GP
 1e-06 0.999999 0.5 0.5 0.5 0 -99 0 0 0 0 0 0 0 # FracFemale_GP_1
#  M2 parameter for each predator fleet
#
# timevary MG parameters 
#_ LO HI INIT PRIOR PR_SD PR_type  PHASE_M1_010
0.05	3	0.466	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1974			
0.05	3	0.397	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1975			
0.05	3	0.389	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1976			
0.05	3	0.532	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1977			
0.05	3	0.737	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1978			
0.05	3	0.823	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1979			
0.05	3	0.715	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1980			
0.05	3	0.724	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1981			
0.05	3	0.675	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1982			
0.05	3	0.608	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1983			
0.05	3	0.503	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1984			
0.05	3	0.450	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1985			
0.05	3	0.416	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1986			
0.05	3	0.450	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1987			
0.05	3	0.395	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1988			
0.05	3	0.301	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1989			
0.05	3	0.189	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1990			
0.05	3	0.152	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1991			
0.05	3	0.184	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1992			
0.05	3	0.236	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1993			
0.05	3	0.206	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1994			
0.05	3	0.179	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1995			
0.05	3	0.154	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1996			
0.05	3	0.139	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1997			
0.05	3	0.163	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1998			
0.05	3	0.187	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_1999			
0.05	3	0.212	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2000			
0.05	3	0.222	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2001			
0.05	3	0.209	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2002			
0.05	3	0.176	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2003			
0.05	3	0.203	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2004			
0.05	3	0.247	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2005			
0.05	3	0.249	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2006			
0.05	3	0.262	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2007			
0.05	3	0.267	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2008			
0.05	3	0.297	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2009			
0.05	3	0.317	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2010			
0.05	3	0.295	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2011			
0.05	3	0.276	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2012			
0.05	3	0.292	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2013			
0.05	3	0.237	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2014			
0.05	3	0.221	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2015			
0.05	3	0.198	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2016			
0.05	3	0.179	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2017			
0.05	3	0.177	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2018			
0.05	3	0.158	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2019			
0.05	3	0.154	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2020			
0.05	3	0.140	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2021			
0.05	3	0.140	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2022			
0.05	3	0.140	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2023			
0.05	3	0.140	0	99	-1	-4	#	NatM_p_1_Fem_GP_0_BLK1repl_2024 #3 yr average 2022-2024			
0.05	3	0.436	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1974			
0.05	3	0.483	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1975			
0.05	3	0.415	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1976			
0.05	3	0.464	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1977			
0.05	3	0.695	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1978			
0.05	3	0.880	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1979			
0.05	3	0.897	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1980			
0.05	3	0.810	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1981			
0.05	3	0.828	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1982			
0.05	3	0.738	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1983			
0.05	3	0.631	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1984			
0.05	3	0.537	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1985			
0.05	3	0.489	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1986			
0.05	3	0.497	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1987			
0.05	3	0.506	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1988			
0.05	3	0.419	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1989			
0.05	3	0.275	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1990			
0.05	3	0.214	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1991			
0.05	3	0.222	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1992			
0.05	3	0.285	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1993			
0.05	3	0.294	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1994			
0.05	3	0.256	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1995			
0.05	3	0.221	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1996			
0.05	3	0.197	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1997			
0.05	3	0.203	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1998			
0.05	3	0.230	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_1999			
0.05	3	0.351	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2000			
0.05	3	0.372	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2001			
0.05	3	0.384	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2002			
0.05	3	0.337	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2003			
0.05	3	0.309	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2004			
0.05	3	0.366	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2005			
0.05	3	0.400	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2006			
0.05	3	0.407	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2007			
0.05	3	0.431	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2008			
0.05	3	0.445	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2009			
0.05	3	0.491	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2010			
0.05	3	0.500	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2011			
0.05	3	0.448	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2012			
0.05	3	0.429	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2013			
0.05	3	0.434	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2014			
0.05	3	0.360	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2015			
0.05	3	0.339	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2016			
0.05	3	0.307	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2017			
0.05	3	0.288	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2018			
0.05	3	0.285	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2019			
0.05	3	0.268	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2020			
0.05	3	0.262	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2021			
0.05	3	0.262	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2022			
0.05	3	0.262	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2023			
0.05	3	0.262	0	99	-1	-4	#	NatM_p_1_Fem_GP_1_BLK1repl_2024 #3 yr average 2022-2024			
0.05	3	0.299	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1974			
0.05	3	0.332	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1975			
0.05	3	0.296	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1976			
0.05	3	0.316	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1977			
0.05	3	0.379	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1978			
0.05	3	0.407	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1979			
0.05	3	0.519	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1980			
0.05	3	0.501	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1981			
0.05	3	0.481	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1982			
0.05	3	0.535	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1983			
0.05	3	0.477	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1984			
0.05	3	0.427	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1985			
0.05	3	0.367	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1986			
0.05	3	0.300	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1987			
0.05	3	0.360	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1988			
0.05	3	0.273	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1989			
0.05	3	0.191	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1990			
0.05	3	0.173	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1991			
0.05	3	0.175	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1992			
0.05	3	0.229	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1993			
0.05	3	0.236	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1994			
0.05	3	0.213	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1995			
0.05	3	0.196	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1996			
0.05	3	0.179	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1997			
0.05	3	0.171	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1998			
0.05	3	0.188	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_1999			
0.05	3	0.256	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2000			
0.05	3	0.270	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2001			
0.05	3	0.287	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2002			
0.05	3	0.230	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2003			
0.05	3	0.280	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2004			
0.05	3	0.310	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2005			
0.05	3	0.271	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2006			
0.05	3	0.289	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2007			
0.05	3	0.291	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2008			
0.05	3	0.318	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2009			
0.05	3	0.359	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2010			
0.05	3	0.328	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2011			
0.05	3	0.256	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2012			
0.05	3	0.276	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2013			
0.05	3	0.282	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2014			
0.05	3	0.241	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2015			
0.05	3	0.298	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2016			
0.05	3	0.234	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2017			
0.05	3	0.213	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2018			
0.05	3	0.201	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2019			
0.05	3	0.198	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2020			
0.05	3	0.196	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2021			
0.05	3	0.196	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2022			
0.05	3	0.196	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2023			
0.05	3	0.196	0	99	-1	-4	#	NatM_p_1_Fem_GP_2_BLK1repl_2024 #3 yr average 2022-2024				
0.05	3	0.237	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1974			
0.05	3	0.263	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1975			
0.05	3	0.244	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1976			
0.05	3	0.258	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1977			
0.05	3	0.330	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1978			
0.05	3	0.341	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1979			
0.05	3	0.410	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1980			
0.05	3	0.386	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1981			
0.05	3	0.388	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1982			
0.05	3	0.368	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1983			
0.05	3	0.364	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1984			
0.05	3	0.315	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1985			
0.05	3	0.322	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1986			
0.05	3	0.254	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1987			
0.05	3	0.252	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1988			
0.05	3	0.274	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1989			
0.05	3	0.168	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1990			
0.05	3	0.146	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1991			
0.05	3	0.151	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1992			
0.05	3	0.188	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1993			
0.05	3	0.204	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1994			
0.05	3	0.194	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1995			
0.05	3	0.173	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1996			
0.05	3	0.159	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1997			
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1998			
0.05	3	0.164	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_1999			
0.05	3	0.241	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2000			
0.05	3	0.235	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2001			
0.05	3	0.250	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2002			
0.05	3	0.210	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2003			
0.05	3	0.217	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2004			
0.05	3	0.277	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2005			
0.05	3	0.267	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2006			
0.05	3	0.261	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2007			
0.05	3	0.267	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2008			
0.05	3	0.267	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2009			
0.05	3	0.295	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2010			
0.05	3	0.302	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2011			
0.05	3	0.262	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2012			
0.05	3	0.215	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2013			
0.05	3	0.229	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2014			
0.05	3	0.213	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2015			
0.05	3	0.211	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2016			
0.05	3	0.216	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2017			
0.05	3	0.179	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2018			
0.05	3	0.186	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2019			
0.05	3	0.176	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2020			
0.05	3	0.183	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2021			
0.05	3	0.183	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2022			
0.05	3	0.183	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2023			
0.05	3	0.183	0	99	-1	-4	#	NatM_p_1_Fem_GP_3_BLK1repl_2024 #3 yr average 2022-2024				
0.05	3	0.216	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1974			
0.05	3	0.239	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1975			
0.05	3	0.223	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1976			
0.05	3	0.237	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1977			
0.05	3	0.308	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1978			
0.05	3	0.327	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1979			
0.05	3	0.363	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1980			
0.05	3	0.330	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1981			
0.05	3	0.322	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1982			
0.05	3	0.341	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1983			
0.05	3	0.288	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1984			
0.05	3	0.264	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1985			
0.05	3	0.249	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1986			
0.05	3	0.237	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1987			
0.05	3	0.240	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1988			
0.05	3	0.225	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1989			
0.05	3	0.175	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1990			
0.05	3	0.129	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1991			
0.05	3	0.126	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1992			
0.05	3	0.171	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1993			
0.05	3	0.174	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1994			
0.05	3	0.175	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1995			
0.05	3	0.163	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1996			
0.05	3	0.150	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1997			
0.05	3	0.140	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1998			
0.05	3	0.154	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_1999			
0.05	3	0.229	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2000			
0.05	3	0.230	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2001			
0.05	3	0.226	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2002			
0.05	3	0.199	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2003			
0.05	3	0.204	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2004			
0.05	3	0.229	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2005			
0.05	3	0.252	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2006			
0.05	3	0.241	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2007			
0.05	3	0.244	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2008			
0.05	3	0.256	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2009			
0.05	3	0.257	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2010			
0.05	3	0.261	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2011			
0.05	3	0.229	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2012			
0.05	3	0.220	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2013			
0.05	3	0.194	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2014			
0.05	3	0.193	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2015			
0.05	3	0.198	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2016			
0.05	3	0.180	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2017			
0.05	3	0.177	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2018			
0.05	3	0.168	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2019			
0.05	3	0.169	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2020			
0.05	3	0.169	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2021			
0.05	3	0.169	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2022			
0.05	3	0.169	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2023			
0.05	3	0.169	0	99	-1	-4	#	NatM_p_1_Fem_GP_4_BLK1repl_2024 #3 yr average 2022-2024				
0.05	3	0.202	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1974			
0.05	3	0.224	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1975			
0.05	3	0.210	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1976			
0.05	3	0.222	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1977			
0.05	3	0.285	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1978			
0.05	3	0.312	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1979			
0.05	3	0.368	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1980			
0.05	3	0.296	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1981			
0.05	3	0.287	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1982			
0.05	3	0.297	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1983			
0.05	3	0.287	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1984			
0.05	3	0.231	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1985			
0.05	3	0.226	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1986			
0.05	3	0.201	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1987			
0.05	3	0.221	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1988			
0.05	3	0.197	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1989			
0.05	3	0.149	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1990			
0.05	3	0.140	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1991			
0.05	3	0.117	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1992			
0.05	3	0.152	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1993			
0.05	3	0.163	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1994			
0.05	3	0.164	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1995			
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1996			
0.05	3	0.141	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1997			
0.05	3	0.132	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1998			
0.05	3	0.142	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_1999			
0.05	3	0.220	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2000			
0.05	3	0.216	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2001			
0.05	3	0.219	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2002			
0.05	3	0.192	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2003			
0.05	3	0.185	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2004			
0.05	3	0.204	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2005			
0.05	3	0.226	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2006			
0.05	3	0.228	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2007			
0.05	3	0.218	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2008			
0.05	3	0.228	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2009			
0.05	3	0.251	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2010			
0.05	3	0.237	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2011			
0.05	3	0.203	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2012			
0.05	3	0.195	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2013			
0.05	3	0.201	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2014			
0.05	3	0.177	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2015			
0.05	3	0.185	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2016			
0.05	3	0.173	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2017			
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2018			
0.05	3	0.167	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2019			
0.05	3	0.158	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2020			
0.05	3	0.164	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2021			
0.05	3	0.164	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2022			
0.05	3	0.164	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2023			
0.05	3	0.164	0	99	-1	-4	#	NatM_p_1_Fem_GP_5_BLK1repl_2024 #3 yr average 2022-2024				
0.05	3	0.200	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1974			
0.05	3	0.223	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1975			
0.05	3	0.209	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1976			
0.05	3	0.220	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1977			
0.05	3	0.259	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1978			
0.05	3	0.303	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1979			
0.05	3	0.316	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1980			
0.05	3	0.298	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1981			
0.05	3	0.268	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1982			
0.05	3	0.266	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1983			
0.05	3	0.257	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1984			
0.05	3	0.224	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1985			
0.05	3	0.207	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1986			
0.05	3	0.184	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1987			
0.05	3	0.197	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1988			
0.05	3	0.186	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1989			
0.05	3	0.141	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1990			
0.05	3	0.121	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1991			
0.05	3	0.126	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1992			
0.05	3	0.142	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1993			
0.05	3	0.151	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1994			
0.05	3	0.159	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1995			
0.05	3	0.147	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1996			
0.05	3	0.136	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1997			
0.05	3	0.126	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1998			
0.05	3	0.132	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_1999			
0.05	3	0.205	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2000			
0.05	3	0.207	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2001			
0.05	3	0.207	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2002			
0.05	3	0.185	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2003			
0.05	3	0.179	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2004			
0.05	3	0.189	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2005			
0.05	3	0.197	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2006			
0.05	3	0.198	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2007			
0.05	3	0.226	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2008			
0.05	3	0.211	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2009			
0.05	3	0.232	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2010			
0.05	3	0.231	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2011			
0.05	3	0.194	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2012			
0.05	3	0.181	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2013			
0.05	3	0.181	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2014			
0.05	3	0.176	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2015			
0.05	3	0.175	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2016			
0.05	3	0.163	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2017			
0.05	3	0.153	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2018			
0.05	3	0.152	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2019			
0.05	3	0.159	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2020			
0.05	3	0.158	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2021			
0.05	3	0.158	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2022			
0.05	3	0.158	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2023			
0.05	3	0.158	0	99	-1	-4	#	NatM_p_1_Fem_GP_6_BLK1repl_2024 #3 yr average 2022-2024				
0.05	3	0.185	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1974			
0.05	3	0.208	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1975			
0.05	3	0.196	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1976			
0.05	3	0.205	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1977			
0.05	3	0.243	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1978			
0.05	3	0.267	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1979			
0.05	3	0.290	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1980			
0.05	3	0.261	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1981			
0.05	3	0.265	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1982			
0.05	3	0.249	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1983			
0.05	3	0.231	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1984			
0.05	3	0.211	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1985			
0.05	3	0.193	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1986			
0.05	3	0.173	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1987			
0.05	3	0.178	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1988			
0.05	3	0.167	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1989			
0.05	3	0.135	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1990			
0.05	3	0.124	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1991			
0.05	3	0.114	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1992			
0.05	3	0.150	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1993			
0.05	3	0.137	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1994			
0.05	3	0.146	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1995			
0.05	3	0.142	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1996			
0.05	3	0.132	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1997			
0.05	3	0.125	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1998			
0.05	3	0.129	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_1999			
0.05	3	0.196	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2000			
0.05	3	0.204	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2001			
0.05	3	0.199	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2002			
0.05	3	0.177	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2003			
0.05	3	0.173	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2004			
0.05	3	0.180	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2005			
0.05	3	0.188	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2006			
0.05	3	0.186	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2007			
0.05	3	0.199	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2008			
0.05	3	0.226	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2009			
0.05	3	0.217	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2010			
0.05	3	0.212	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2011			
0.05	3	0.183	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2012			
0.05	3	0.175	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2013			
0.05	3	0.174	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2014			
0.05	3	0.166	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2015			
0.05	3	0.170	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2016			
0.05	3	0.154	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2017			
0.05	3	0.150	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2018			
0.05	3	0.148	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2019			
0.05	3	0.146	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2020			
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2021			
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2022			
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2023			
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_7_BLK1repl_2024 #3 yr average 2022-2024				
0.05	3	0.155	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1974			
0.05	3	0.172	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1975			
0.05	3	0.164	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1976			
0.05	3	0.171	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1977			
0.05	3	0.212	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1978			
0.05	3	0.216	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1979			
0.05	3	0.253	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1980			
0.05	3	0.222	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1981			
0.05	3	0.211	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1982			
0.05	3	0.219	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1983			
0.05	3	0.205	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1984			
0.05	3	0.188	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1985			
0.05	3	0.168	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1986			
0.05	3	0.154	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1987			
0.05	3	0.156	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1988			
0.05	3	0.147	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1989			
0.05	3	0.127	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1990			
0.05	3	0.115	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1991			
0.05	3	0.111	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1992			
0.05	3	0.129	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1993			
0.05	3	0.135	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1994			
0.05	3	0.144	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1995			
0.05	3	0.130	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1996			
0.05	3	0.126	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1997			
0.05	3	0.114	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1998			
0.05	3	0.118	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_1999			
0.05	3	0.194	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2000			
0.05	3	0.200	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2001			
0.05	3	0.205	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2002			
0.05	3	0.175	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2003			
0.05	3	0.166	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2004			
0.05	3	0.171	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2005			
0.05	3	0.179	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2006			
0.05	3	0.171	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2007			
0.05	3	0.188	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2008			
0.05	3	0.202	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2009			
0.05	3	0.214	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2010			
0.05	3	0.213	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2011			
0.05	3	0.173	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2012			
0.05	3	0.168	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2013			
0.05	3	0.168	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2014			
0.05	3	0.162	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2015			
0.05	3	0.163	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2016			
0.05	3	0.150	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2017			
0.05	3	0.143	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2018			
0.05	3	0.144	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2019			
0.05	3	0.145	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2020			
0.05	3	0.149	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2021			
0.05	3	0.149	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2022			
0.05	3	0.149	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2023			
0.05	3	0.149	0	99	-1	-4	#	NatM_p_1_Fem_GP_8+_BLK1repl_2024 #3 yr average 2022-2024				


# info on dev vectors created for MGparms are reported with other devs after tag parameter section 
#
#_seasonal_effects_on_biology_parms
 0 0 0 0 0 0 0 0 0 0 #_femwtlen1,femwtlen2,mat1,mat2,fec1,fec2,Malewtlen1,malewtlen2,L1,K
#_ LO HI INIT PRIOR PR_SD PR_type PHASE
#_Cond -2 2 0 0 -1 99 -2 #_placeholder when no seasonal MG parameters
#
3 #_Spawner-Recruitment; Options: 1=NA; 2=Ricker; 3=std_B-H; 4=SCAA; 5=Hockey; 6=B-H_flattop; 7=survival_3Parm; 8=Shepherd_3Parm; 9=RickerPower_3parm
0  # 0/1 to use steepness in initial equ recruitment calculation
0  #  future feature:  0/1 to make realized sigmaR a function of SR curvature
#_          LO            HI          INIT         PRIOR         PR_SD       PR_type      PHASE    env-var    use_dev   dev_mnyr   dev_mxyr     dev_PH      Block    Blk_Fxn #  parm_name
            16            25       17.7696        12.545             2             0          1          0          0          0          0          0          0          0 # SR_LN(R0)
           0.1             1          0.74          0.74         0.113             2          1          0          0          0          0          0          0          0 # SR_BH_steep
             0             2           0.5          0.23          0.05             0         -2          0          0          0          0          0          0          0 # SR_sigmaR
            -5             5             0             0             1             0         -1          0          0          0          0          0          0          0 # SR_regime
             0             1          0.18         0.456         0.054             0         -2          0          0          0          0          0          0          0 # SR_autocorr
#_no timevary SR parameters
1 #do_recdev:  0=none; 1=devvector (R=F(SSB)+dev); 2=deviations (R=F(SSB)+dev); 3=deviations (R=R0*dev; dev2=R-f(SSB)); 4=like 3 with sum(dev2) adding penalty
1974 # first year of main recr_devs; early devs can preceed this era
2023 # last year of main recr_devs; forecast devs start in following year
2 #_recdev phase 
1 # (0/1) to read 13 advanced options
 -8 #_recdev_early_start (0=none; neg value makes relative to recdev_start)
 3 #_recdev_early_phase
 0 #_forecast_recruitment phase (incl. late recr) (0 value resets to maxphase+1)
 1 #_lambda for Fcast_recr_like occurring before endyr+1
 1964.0   #_last_early_yr_nobias_adj_in_MPD 
 1971.5   #_first_yr_fullbias_adj_in_MPD 
 2023.9   #_last_yr_fullbias_adj_in_MPD 
 2024.1   #_first_recent_yr_nobias_adj_in_MPD 
 0.9501  #_max_bias_adj_in_MPD (1.0 to mimic pre-2009 models) (typical ~0.8; -3 sets all years to 0.0; -2 sets all non-forecast yrs w/ estimated recdevs to 1.0; -1 sets biasadj=1.0 for all yrs w/ recdevs)
 0 #_period of cycles in recruitment (N parms read below)
 -5 #min rec_dev
 5 #max rec_dev
 0 #_read_recdevs
#_end of advanced SR options
#
#_placeholder for full parameter lines for recruitment cycles
# read specified recr devs
#_Yr Input_value
#
# all recruitment deviations
#  1966E 1967E 1968E 1969E 1970E 1971E 1972E 1973E 1974R 1975R 1976R 1977R 1978R 1979R 1980R 1981R 1982R 1983R 1984R 1985R 1986R 1987R 1988R 1989R 1990R 1991R 1992R 1993R 1994R 1995R 1996R 1997R 1998R 1999R 2000R 2001R 2002R 2003R 2004R 2005R 2006R 2007R 2008R 2009R 2010R 2011R 2012R 2013R 2014R 2015R 2016R 2017R 2018R 2019R 2020R 2021R 2022F 2023F 2024F
#  -1.58174 -0.775032 -0.857867 -0.764039 -0.0599698 -0.320418 0.0538474 0.147141 0.231412 1.0583 0.554811 0.531374 0.0694033 0.599196 1.09625 0.680956 0.462776 0.851897 0.747918 0.0145493 0.790416 -0.263849 0.259233 0.489462 -0.0810501 -0.133186 -0.351549 -0.593268 -0.233736 -0.29748 -0.795079 -0.169626 -0.82917 0.0116316 -0.254135 -0.0993682 0.544412 -0.0681706 -0.546462 -0.00652938 -0.276627 0.261341 -0.161327 -0.480063 -0.902189 -0.146412 -0.188966 -0.535417 0.581143 -0.52355 -0.454402 -0.270111 -0.814839 0.161482 -0.427332 -0.0940669 0 0 0
#
#Fishing Mortality info 
0.23 # F ballpark value in units of annual_F
-2008 # F ballpark year (neg value to disable)
4 # F_Method:  1=Pope midseason rate; 2=F as parameter; 3=F as hybrid; 4=fleet-specific parm/hybrid (#4 is superset of #2 and #3 and is recommended)
2.3 # max F (methods 2-4) or harvest fraction (method 1)
1 0.05 99 # Fleet
#2 0.05 1 # Acoustic
-9999 1 1 # end of list
4  # N iterations for tuning in hybrid mode; recommend 3 (faster) to 5 (more precise if many fleets)
#
#_initial_F_parms; for each fleet x season that has init_catch; nest season in fleet; count = 1
#_for unconstrained init_F, use an arbitrary initial catch and set lambda=0 for its logL
#_ LO HI INIT PRIOR PR_SD  PR_type  PHASE
 0.001 1 0.0090 0.1 0.1 0 -1 # InitF_seas_1_flt_1Fleet
#
# F rates by fleet x season
# Yr:  1974 1975 1976 1977 1978 1979 1980 1981 1982 1983 1984 1985 1986 1987 1988 1989 1990 1991 1992 1993 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024
# seas:  1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
# Fleet 0.249231 0.251143 0.23771 0.230341 0.218473 0.223925 0.230383 0.236799 0.210787 0.23486 0.220407 0.233081 0.221633 0.235223 0.253717 0.309821 0.308686 0.309896 0.296253 0.344408 0.359021 0.363335 0.360423 0.396121 0.499487 0.458635 0.543118 0.475773 0.399344 0.295219 0.24098 0.221532 0.234489 0.230021 0.246059 0.25804 0.262894 0.222749 0.166378 0.158828 0.205419 0.277605 0.348058 0.344887 0.434323 0.436124 0.41731 0.342875 0.302001 0.302001 0.302001
#
#_Q_setup for fleets with cpue or survey data
#_1:  fleet number
#_2:  link type: (1=simple q, 1 parm; 2=mirror simple q, 1 mirrored parm; 3=q and power, 2 parm; 4=mirror with offset, 2 parm)
#_3:  extra input for link, i.e. mirror fleet# or dev index number
#_4:  0/1 to select extra sd parameter
#_5:  0/1 for biasadj or not
#_6:  0/1 to float
#_   fleet      link link_info  extra_se   biasadj     float  #  fleetname
         2         1         0         1         0         1  #  Acoustics
-9999 0 0 0 0 0
#
#_Q_parms(if_any);Qunits_are_ln(q)
#_          LO            HI          INIT         PRIOR         PR_SD       PR_type      PHASE    env-var    use_dev   dev_mnyr   dev_mxyr     dev_PH      Block    Blk_Fxn  #  parm_name
           -25            25      -5.95741             0             1             0         -1          0          0          0          0          0          0          0  #  LnQ_base_Acoustics(2)
             0             1             0           0.1           0.1             0          -3          0          0          0          0          0          0          0  #  Q_extraSD_Acoustics(2)
#_no timevary Q parameters
#
#_size_selex_patterns
#Pattern:_0;  parm=0; selex=1.0 for all sizes
#Pattern:_1;  parm=2; logistic; with 95% width specification
#Pattern:_5;  parm=2; mirror another size selex; PARMS pick the min-max bin to mirror
#Pattern:_11; parm=2; selex=1.0  for specified min-max population length bin range
#Pattern:_15; parm=0; mirror another age or length selex
#Pattern:_6;  parm=2+special; non-parm len selex
#Pattern:_43; parm=2+special+2;  like 6, with 2 additional param for scaling (average over bin range)
#Pattern:_8;  parm=8; double_logistic with smooth transitions and constant above Linf option
#Pattern:_9;  parm=6; simple 4-parm double logistic with starting length; parm 5 is first length; parm 6=1 does desc as offset
#Pattern:_21; parm=2+special; non-parm len selex, read as pairs of size, then selex
#Pattern:_22; parm=4; double_normal as in CASAL
#Pattern:_23; parm=6; double_normal where final value is directly equal to sp(6) so can be >1.0
#Pattern:_24; parm=6; double_normal with sel(minL) and sel(maxL), using joiners
#Pattern:_2;  parm=6; double_normal with sel(minL) and sel(maxL), using joiners, back compatibile version of 24 with 3.30.18 and older
#Pattern:_25; parm=3; exponential-logistic in length
#Pattern:_27; parm=special+3; cubic spline in length; parm1==1 resets knots; parm1==2 resets all 
#Pattern:_42; parm=special+3+2; cubic spline; like 27, with 2 additional param for scaling (average over bin range)
#_discard_options:_0=none;_1=define_retention;_2=retention&mortality;_3=all_discarded_dead;_4=define_dome-shaped_retention
#_Pattern Discard Male Special
 0 0 0 0 # 1 Fleet
 0 0 0 0 # 2 Acoustics
#
#_age_selex_patterns
#Pattern:_0; parm=0; selex=1.0 for ages 0 to maxage
#Pattern:_10; parm=0; selex=1.0 for ages 1 to maxage
#Pattern:_11; parm=2; selex=1.0  for specified min-max age
#Pattern:_12; parm=2; age logistic
#Pattern:_13; parm=8; age double logistic. Recommend using pattern 18 instead.
#Pattern:_14; parm=nages+1; age empirical
#Pattern:_15; parm=0; mirror another age or length selex
#Pattern:_16; parm=2; Coleraine - Gaussian
#Pattern:_17; parm=nages+1; empirical as random walk  N parameters to read can be overridden by setting special to non-zero
#Pattern:_41; parm=2+nages+1; // like 17, with 2 additional param for scaling (average over bin range)
#Pattern:_18; parm=8; double logistic - smooth transition
#Pattern:_19; parm=6; simple 4-parm double logistic with starting age
#Pattern:_20; parm=6; double_normal,using joiners
#Pattern:_26; parm=3; exponential-logistic in age
#Pattern:_27; parm=3+special; cubic spline in age; parm1==1 resets knots; parm1==2 resets all 
#Pattern:_42; parm=2+special+3; // cubic spline; with 2 additional param for scaling (average over bin range)
#Age patterns entered with value >100 create Min_selage from first digit and pattern from remainder
#_Pattern Discard Male Special
 17 0 0 0 # 1 Fleet
 17 0 0 0 # 2 Acoustics
#
#_          LO            HI          INIT         PRIOR         PR_SD       PR_type      PHASE    env-var    use_dev   dev_mnyr   dev_mxyr     dev_PH      Block    Blk_Fxn  #  parm_name
# 1   Fleet LenSelex
# 2   Acoustics LenSelex
# 1   Fleet AgeSelex
         -1002             3         -1000            -1            -1          0.01         -4          0          0          0          0          0          0          0  #  AgeSel_P1_Fleet(1)
           -25            25             1            -1            -1          0.01         -4          0          0          0          0          0          0          0  #  AgeSel_P2_Fleet(1)
            -5             9      0.795288            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P3_Fleet(1)
            -5             9      0.365896            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P4_Fleet(1)
            -5             9      0.187828            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P5_Fleet(1)
            -5             9     0.0871786            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P6_Fleet(1)
            -5             9             0            -1            -1          0.01          -4          0          0          0          0          0          0          0  #  AgeSel_P7_Fleet(1)
            -5             9             0            -1            -1          0.01          -4          0          0          0          0          0          0          0  #  AgeSel_P8_Fleet(1)
            -5             9             0            -1            -1          0.01         -4          0          0          0          0          0          0          0  #  AgeSel_P9_Fleet(1)
# 2   Acoustics AgeSelex
         -1002             3         -1000            -1            -1          0.01         -4          0          0          0          0          0          0          0  #  AgeSel_P1_Acoustics(2)
           -25            25             1            -1            -1          0.01         -4          0          0          0          0          0          0          0  #  AgeSel_P2_Acoustics(2)   
 #          -25            25             1            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P2_Acoustics(2)
            -5             9      0.689216            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P3_Acoustics(2)
            -5             9      0.504161            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P4_Acoustics(2)
            -5             9      0.242689            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P5_Acoustics(2)
            -5             9             0            -1            -1          0.01          4          0          0          0          0          0          0          0  #  AgeSel_P6_Acoustics(2)
            -5             9             0            -1            -1          0.01          -4          0          0          0          0          0          0          0  #  AgeSel_P7_Acoustics(2)
            -5             9             0            -1            -1          0.01          -4          0          0          0          0          0          0          0  #  AgeSel_P8_Acoustics(2)
            -5             9             0            -1            -1          0.01         -4          0          0          0          0          0          0          0  #  AgeSel_P9_Acoustics(2)
#_No_Dirichlet parameters
-5            5            5             0            1.813             6              5          0          0          0          0          0          0          0  #  ln(EffN_mult)_1
-5            5            5             0            1.813             6              5          0          0          0          0          0          0          0  #  ln(EffN_mult)_1
#_no timevary selex parameters
#
0   #  use 2D_AR1 selectivity(0/1)
#_no 2D_AR1 selex offset used
#
# Tag loss and Tag reporting parameters go next
0  # TG_custom:  0=no read and autogen if tag data exist; 1=read
#_Cond -6 6 1 1 2 0.01 -4 0 0 0 0 0 0 0  #_placeholder if no parameters
#
# deviation vectors for timevary parameters
#  base   base first block   block  env  env   dev   dev   dev   dev   dev
#  type  index  parm trend pattern link  var  vectr link _mnyr  mxyr phase  dev_vector
#      1     1     1     1     2     0     0     0     0     0     0     0
#      1     2     6     1     2     0     0     0     0     0     0     0
#      1     3    11     1     2     0     0     0     0     0     0     0
#      1     4    16     1     2     0     0     0     0     0     0     0
#      1     5    21     1     2     0     0     0     0     0     0     0
#      1     6    26     1     1     0     0     0     0     0     0     0
     #
# Input variance adjustments factors: 
 #_1=add_to_survey_CV
 #_2=add_to_discard_stddev
 #_3=add_to_bodywt_CV
 #_4=mult_by_lencomp_N
 #_5=mult_by_agecomp_N
 #_6=mult_by_size-at-age_N
 #_7=mult_by_generalized_sizecomp
#_Factor  Fleet  Value
#      5      1         1
#      5      2         1
 -9999   1    0  # terminator
#
4 #_maxlambdaphase
1 #_sd_offset; must be 1 if any growthCV, sigmaR, or survey extraSD is an estimated parameter
# read 0 changes to default Lambdas (default value is 1.0)
# Like_comp codes:  1=surv; 2=disc; 3=mnwt; 4=length; 5=age; 6=SizeFreq; 7=sizeage; 8=catch; 9=init_equ_catch; 
# 10=recrdev; 11=parm_prior; 12=parm_dev; 13=CrashPen; 14=Morphcomp; 15=Tag-comp; 16=Tag-negbin; 17=F_ballpark; 18=initEQregime
#like_comp fleet  phase  value  sizefreq_method
5 1 1 1.00 1
-9999  1  1  1  1  #  terminator
#
# lambdas (for info only; columns are phases)
#  0 0 0 0 #_CPUE/survey:_1
#  1 1 1 1 #_CPUE/survey:_2
#  1 1 1 1 #_agecomp:_1
#  1 1 1 1 #_agecomp:_2
#  1 1 1 1 #_init_equ_catch1
#  1 1 1 1 #_init_equ_catch2
#  1 1 1 1 #_recruitments
#  1 1 1 1 #_parameter-priors
#  1 1 1 1 #_parameter-dev-vectors
#  1 1 1 1 #_crashPenLambda
#  0 0 0 0 # F_ballpark_lambda
0 # (0/1/2) read specs for more stddev reporting: 0 = skip, 1 = read specs for reporting stdev for selectivity, size, and numbers, 2 = add options for M,Dyn. Bzero, SmryBio
 # 0 2 0 0 # Selectivity: (1) fleet, (2) 1=len/2=age/3=both, (3) year, (4) N selex bins
 # 0 0 # Growth: (1) growth pattern, (2) growth ages
 # 0 0 0 # Numbers-at-age: (1) area(-1 for all), (2) year, (3) N ages
 # -1 # list of bin #'s for selex std (-1 in first bin to self-generate)
 # -1 # list of ages for growth std (-1 in first bin to self-generate)
 # -1 # list of ages for NatAge std (-1 in first bin to self-generate)
999

